import Dashboard from 'layouts/Dashboard/Dashboard.jsx';

var indexRoutes = [
    { path: "/", name: "Home", component: Dashboard },
    { path: "/login" },

];

export default indexRoutes;
